<?php

return [
    'app' => [
        'purchase_code' => ''
    ]
];
